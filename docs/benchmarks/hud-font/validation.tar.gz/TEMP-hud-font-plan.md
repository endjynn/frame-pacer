# Scalable HUD font plan

Status: both rendering paths, GPU pixel tests, and the user-approved reduced
performance investigation are complete. Raw benchmark evidence and all initial
flags/reruns are preserved in `docs/benchmarks/hud-font`. The normal `make check`
suite passes. Final quality/sanitizer and requirement-by-requirement audit remain;
the overall feature is not yet marked complete.

## Implementation progress — 2026-09-11

- Implemented the pinned offline FreeType generator and standard-library-only
  preview tool. Generated JetBrains Mono Medium atlases for sizes 8–64 in
  `assets/fonts/hud`; total raw coverage is 1,280,256 bytes. The largest single
  atlas is 55,040 bytes before GPU allocation alignment. The asset manifest
  records input/output checksums and rasterization flags.
- Compared Regular and Medium at native sizes 14, 16, 24, and 32; selected
  Medium for stronger small colored labels. Regenerated comparison data after
  the native-spacing correction below.
- User clarified that the HUD/background must fit the font. Preserve native
  fixed advances and font line metrics. Removed the initial attempt to widen
  cells to contain rasterized ink. At size 14, `%` has an 8-pixel native advance
  and 9-pixel ink bounds; its overhang affects panel bounds, not cell spacing.
- Generator checks verify uniform native advances, glyph presence, bounds,
  and byte-for-byte repeated output. Three independent asset-integrity tests
  pass without FreeType; they also guard against accidentally widening the
  native character advance. Asset regeneration with `--check` has passed.
- Added benchmark-only link wrappers for deterministic three/four-row text.
  They do not activate the CPU quota controller and are not release artifacts.
  The runner now verifies the fixture actually ran and records source/library
  hashes, environment details, GPU identity, and peak RSS. x86_64 GLX/Vulkan
  smoke matrices with 0/3/4 rows completed in `build/font-fixture-shim-smoke`.
- The benchmark must use the GL shim; direct preloading of the backend caused
  probe crashes and was replaced with the normal adjacent-shim loading path.
  Device evidence shows GLX uses Intel RPL-S/Mesa and Vulkan uses the NVIDIA
  RTX 4060 Laptop GPU. Before/after comparisons must match devices per workload.
- Completed the 144-run controlled steady-state baseline (180 frames, 60-frame
  warm-up, three repetitions) in `build/font-baseline-controlled`; preserved
  the baseline sources in `build/font-tools/baseline-source.tar.gz`. Resize
  coverage remains outstanding, so this is not the complete performance gate.
- Added generated C atlas metadata and the embedded read-only coverage reader.
  Automated layout tests preserve native advances and line metrics, check ink
  bounds, and cover 720p through 8K, ultrawide, narrow, and invalid extents.
  Shared geometry now selects these atlases and emits one quad per visible
  glyph. Both backend texture/shader paths still need integration.
- Initial automatic sizing uses 24 px at 1600 pixels of viewport height,
  nearest integer sizes, a preferred minimum of 14 px, and a maximum of 64 px.
  Narrow windows select smaller native sizes down to 8 px; if even that cannot
  fit the full four-row panel, omit the HUD rather than distort the font.
- Replaced fractional bitmap geometry tests with native-size glyph, UV,
  pixel-alignment, bounds, row/column spacing, and maximum-capacity checks.
  Updated the software reference renderer for coverage sampling and RGBA PNG
  output; its previous palette limit cannot represent antialiased colored text.
- Implemented OpenGL single-channel R8 texture upload, nearest sampling at
  native sizes, and coverage alpha blending. One atlas is resident per context;
  size changes replace it, while ordinary draws reuse it. Unpack buffer and
  pixel-store state are saved/restored only around uploads.
- GLX presentation/state checks pass on x86_64/i386, and EGL presentation passes
  on x86_64. Added `make check-gl-hud-pixels`: real GPU readback versus software
  atlas compositing over 20 resolution/row/resize cases. x86_64 passes with no
  channel differences outside the fixed three-byte rounding tolerance.
- Presentation probes now use fixed workload dimensions independent of font
  layout. GLX also checks deliberately nondefault unpack/texture state. This is
  a harness change: rerun the preserved baseline with the identical final probe
  sources before the performance comparison; earlier timings are provisional.
- Integrated Vulkan optimal-tiled R8 image, nearest sampler, descriptor layout
  and set, UV vertex input, and coverage shader. The first overlay command
  records staging-copy and transfer-to-sampling barriers; subsequent draws
  reuse the image. Staging storage remains owned by the swapchain until teardown
  to avoid an additional synchronous upload wait. Both GPU image and staging
  allocation sizes are recorded in the resource object.
- Vulkan shader/build checks, pipeline/record/command unit tests, and live
  presentation smoke probes pass on x86_64/i386. These do not replace pending
  GPU pixel readback, allocation-failure, lifetime, and performance validation.
- Removed the superseded bitmap font sources, tests, and exported font/geometry
  wrappers; updated symbol baselines pass on both architectures. Regenerated
  the maintained HUD image and documented native font sizing and rendering.
- Embedded-font OFL notices now travel in the install/release payload and are
  installed beside runtime files. Installation, upgrade/uninstall, and release
  package tests pass, including both architectures' mocked OpenGL load checks.
  Those mocks were updated for texture calls and the eight-float vertex format.
- Added Vulkan texture failure tests for all 12 fallible creation steps, missing
  suitable image/staging memory types, exact upload contents, descriptor setup,
  barrier order, and cached-upload suppression. Tests pass on x86_64 and i386.
- Added `make check-vulkan-hud-pixels`: GPU readback through production texture,
  pipeline, vertex-buffer, draw-resource, and command-recording modules. Only
  the presentation layout is substituted with GENERAL for offscreen images.
  Forty initial/cached render cases pass on x86_64 and i386, covering the
  resolution/row matrix and RGBA UNORM, BGRA UNORM, and RGBA sRGB targets with a
  fixed three-byte channel tolerance. The color-attachment transition now
  explicitly includes read access for loading/blending the game background.
- Corrected the Vulkan presentation benchmark to clear and transition acquired
  images before presentation; the earlier probe omitted image initialization.
  Both probes now require exact requested extents and use unmanaged test
  windows to avoid asynchronous window-manager resizing. Corrected Vulkan
  presentation probes pass on both architectures. The original baseline must
  be rerun using these corrected sources, not compared directly with new runs.

Remaining prerequisite: finish resize/resource/timing coverage, run repeated
controlled measurements, establish regression tolerances, and freeze the
baseline. Shared geometry integration has started; backend rendering remains
unfinished. Any benchmark harness correction must be applied to the preserved
baseline sources as well as the candidate before comparison.

## Implementation progress — 2026-09-10

- Added opt-in frame timing and extent controls to GLX and Vulkan presentation
  probes, with a shared timing helper and a raw CSV benchmark runner in
  `tools/benchmark_hud.py`. Normal two-frame probe behavior remains supported.
- Benchmark mode requests GLX swap interval zero and Vulkan immediate mode.
  Two 90-frame smoke matrices completed across x86_64/i386, HUD on/off,
  1440×900/3840×2160, and uncapped/60 FPS configurations. Results are under
  `build/font-baseline-smoke` and `build/font-baseline-immediate-smoke`.
- These are **not** the frozen baseline: the harness still needs four-row
  coverage, startup/resize/resource measurements, device/environment provenance,
  validated uncapped behavior, repeated controlled runs, and comparison gates.
  Several uncapped wall-time medians remained near 4.17 ms despite requesting
  immediate presentation. Investigate presentation/compositor/device behavior;
  do not interpret these timings as isolated GPU HUD costs.
- Imported unmodified JetBrains Mono v2.304 Regular/Medium and OFL notices under
  `assets/fonts/jetbrains-mono`, with source and SHA-256 metadata.
- Built FreeType 2.14.3 statically inside `build/font-tools` without installing
  system packages. Archive SHA-256:
  `36bc4f1cc413335368ee656c42afca65c5a3987e8768cc28cf11ba775e785a5f`.
  Configure options: `--with-zlib=no --with-bzip2=no --with-png=no
  --with-harfbuzz=no --with-brotli=no --disable-shared --enable-static`.
  Reproducible generator/bootstrap integration remains to be written.
- Vulkan/GLX presentation probes pass on both architectures; EGL passes on
  x86_64 after instrumentation changes. No system configuration was modified.

Next: finish and freeze the benchmark prerequisites before changing production
rendering. Then generate/compare atlases, implement both backends, remove the
legacy font path, and complete the required performance/quality gates.

## Architectural decision record

- Font: JetBrains Mono Medium, selected after native-size comparisons.
- Asset pipeline: offline FreeType grayscale rasterization at supported integer
  text sizes. Pin the font, generator version, and generation settings.
- Distribution: embed generated raw coverage data and metrics; retain font
  source, copyright, OFL text, and reproducible generation instructions.
- Dependencies: no new runtime or normal build dependencies, font discovery,
  downloads, font parser, or image decoder. FreeType is maintainer tooling only.
- Rendering: one textured quad per glyph, shared data/layout for Vulkan and
  OpenGL; backend-specific GPU resources and lifecycle management.
- Scaling: choose text size from output extent, respect a readable minimum and
  narrow-window bounds, use native-size atlas glyphs and pixel-aligned origins.
  Derive row/column spacing and panel padding from the chosen font metrics.
- Preserve the font's native fixed horizontal advance and vertical line metrics.
  Size the HUD/background around the resulting text and ink bounds; do not
  widen character cells or stretch glyphs to fit a preselected HUD rectangle.
  Ink overhangs belong in panel bounds/padding, not in character advances.
- Steady state: no font rasterization or atlas regeneration in the game process.
  Select/upload existing data when needed and reuse GPU resources thereafter.
- Compatibility: preserve existing HUD content, colors, optional rows, pacing,
  telemetry behavior, and supported architectures/backends.
- Replacement: remove the old bitmap implementation and affected obsolete
  tests/build rules; no permanent fallback or parallel legacy renderer.
- Performance: record the current implementation with a frozen benchmark
  harness before production changes, rerun it afterward, and require the
  documented performance gate to pass.

Open implementation details remain explicitly listed below. Texture format,
hinting, exact size range, cache ownership, and numerical performance budgets
are not yet agreed decisions.

## Goal

Keep the HUD readable and visually proportional across a wide range of game
resolutions, including 1440×900, while retaining low rendering overhead.

## Current problem

The HUD uses project-owned 5×7 bitmap glyphs. Each lit font pixel is rendered
as a quad. Geometry scales proportionally from a 2560×1600 reference with a
font-pixel scale of 2.5. At 1440×900, that becomes 1.40625, producing uneven
stroke widths when rasterized to screen pixels.

Both supplied screenshots are 2560×1600. Further enlargement of a lower
resolution game image may also soften the HUD; the screenshots alone do not
establish the exact scaling path.

## Selected approach

Use **JetBrains Mono**, generated offline into grayscale coverage atlases with
FreeType and embedded in frame-pacer. The font family is decided; alternatives
such as Intel One Mono and Hack do not need further evaluation.

- Pin an unmodified upstream JetBrains Mono font and preserve its OFL notices.
- Generate only the HUD's required glyphs at supported integer text sizes.
- Commit raw atlas data, metrics, and reproducible generation tooling. FreeType
  is needed only to regenerate assets, not for normal builds or runtime use.
- Select the nearest supported text size at runtime and upload its atlas as
  needed. Do not stretch glyphs or rasterize fonts inside the game process.
- Share generated font data, metrics, and layout between Vulkan and OpenGL.
- Render one textured quad per glyph with antialiasing and alpha blending.
- Scale layout primarily with viewport height, constrain it for narrow
  windows, and enforce a minimum readable text size where space permits.
- Align text origins and panel boundaries to whole pixels. Derive padding,
  row spacing, and column placement from font metrics.
- Preserve existing metrics, colors, optional rows, and background behavior.

JetBrains Mono Medium was selected after native-size comparison with Regular.
Generated integer sizes cover 8–64 pixels; the viewport selection policy and
final GPU rendering parameters remain to be finalized.

## Expected costs

Estimates below need measurement with the selected weight and atlas size range.

| Area | Expected impact |
| --- | --- |
| Atlas memory | 64 KiB for a 256×256 single-channel atlas; 256 KiB for 512×512, excluding allocation overhead. RGBA uses four times as much. |
| GPU work | Texture sampling and blending over the small HUD area; fewer vertices than the current per-pixel geometry. |
| CPU steady state | Glyph layout and quad generation; no font rasterization per frame. |
| Startup and resize | Atlas selection, texture allocation, and upload when the required size changes; no runtime font rasterization. |
| Binary size | Embedded atlas data and metrics; no font parser or rasterizer code. Measure the full supported size range. |
| Build cost | Embedded data and shader updates; no new ordinary build dependencies. FreeType runs only in the optional asset-generation workflow. |
| Engineering | Moderate rendering refactor, primarily texture lifetime, Vulkan uploads/descriptors/synchronization, and OpenGL state preservation. |

## Decisions to resolve

- Confirm final runtime glyph mapping and rendering against the generated
  JetBrains Mono Medium v2.304 / FreeType 2.14.3 assets.
- Target font size at the reference resolution, minimum size, and scaling curve.
- Pixel-size quantization and atlas reuse during repeated window resizing.
- Coverage texture format, filtering, and blending behavior across supported
  presentation formats, including sRGB.
- Resource ownership across multiple windows, swapchains, and GL contexts.
- Failure behavior when offline generation or runtime GPU allocation fails, without
  retaining a parallel legacy font renderer.
- Whether this remains automatic or needs a user-facing size setting.

## Implementation outline

0. Establish and run the performance benchmark suite against the current
   implementation; preserve the baseline before changing production rendering.
1. Pin JetBrains Mono and FreeType generation inputs, select weight, document
   licensing, and define sizing rules.
2. Implement offline atlas generation and shared runtime glyph metrics/layout.
3. Integrate texture upload and glyph sampling into Vulkan and OpenGL.
4. Handle resize, resource destruction, and allocation failures safely.
5. Replace the bitmap implementation and remove superseded code, tests, and
   build rules. Update HUD documentation and reference imagery.
6. Complete automated visual, correctness, and performance validation.

## Validation

- Capture baseline HUD appearance and CPU/GPU costs before implementation.
- Render deterministic HUD samples at 1280×720, 1440×900, 1920×1080,
  2560×1440, 2560×1600, 3840×2160, and representative ultrawide and tiny extents.
- Verify legibility, consistent columns and spacing, panel bounds, all required
  glyphs, and three- and four-row layouts with automated rendering checks.
- Exercise Vulkan and OpenGL, repeated resize, multiple presentation resources,
  cleanup, failure paths, and preservation of game rendering state.
- Verify normal builds work without FreeType or font downloads, and verify
  reproducible asset generation separately.
- Measure atlas memory, binary/build impact, offline generation and runtime upload time,
  and steady-state CPU/GPU overhead against the baseline.
- Set measurable acceptance thresholds before finalizing the implementation;
  completion must not depend on manual game testing.

## Required before-and-after performance benchmark

User-requested scope reduction: use the quick comparison set for the performance
gate, not the full multilib matrix. Keep both backends, 900p/4K, HUD-off controls
and four-row HUD, uncapped/60 FPS, with three repetitions of 120 frames on
x86_64. Add focused uncapped four-row live-resize runs for both backends.
i386 and three-row correctness remain covered by automated rendering tests;
their performance is not separately established by this reduced benchmark.
The larger baseline and partial candidate results remain diagnostic evidence.

Performance preservation is a release gate for this feature. Benchmark the
current frame-pacer implementation before changing its renderer, then run the
same benchmark after implementation and compare the results. A capped FPS
counter alone is not evidence of unchanged overhead.

### Baseline and reproducibility

- Start with the existing `make benchmark-performance` suite. Its presentation
  benchmark disables the HUD, so it is insufficient alone: add automated
  HUD-enabled rendering benchmarks for Vulkan and OpenGL before recording the
  baseline. Exercise public rendering behavior so the same harness works with
  both implementations.
- Freeze the benchmark harness, workloads, metrics, and commands before feature
  work. If a later harness correction is necessary, rerun both implementations
  with that same corrected harness.
- Preserve the baseline source revision and any local changes needed to
  reproduce it, benchmark revision, raw measurements, and environment metadata.
  Keep the baseline reproducible in an isolated checkout; do not retain a legacy
  renderer in the finished product.
- Use the same hardware, drivers, compiler, optimization flags, architecture,
  presentation settings, resolutions, HUD content, and telemetry conditions.
  Record these settings and control background load and warm-up consistently.
  Do not modify system or driver configuration to run these checks.

### Workloads and measurements

- Run HUD-off controls and HUD-on workloads for both backends, with three and
  four rows, at representative resolutions including 1440×900 and 4K. Cover
  supported x86_64 and i386 builds where applicable.
- Measure uncapped rendering to expose overhead and a 60 FPS workload to check
  pacing. Record CPU cost per frame, GPU HUD time where supported, frame-time
  median and p95/p99, throughput, and missed frame deadlines.
- Measure startup and repeated resolution changes separately from steady state,
  including upload latency and allocation spikes. Track process/GPU memory and
  resource cleanup; distinguish the planned atlas footprint from unintended
  growth or leaks.
- Warm up each workload and perform multiple repetitions. Report variability
  and alternate baseline/candidate runs where practical to reduce drift.
  If GPU timing cannot be collected, record the gap and use an automated
  end-to-end rendering measurement; do not infer GPU cost from CPU submission
  timing alone.

### Comparison and acceptance

Frozen numerical comparison policy (before corrected measured runs): for CPU
median use max(2 µs, 5% baseline median, 3× baseline repetition MAD); for wall
median/p95/p99 use max(50 µs, 5%, 3× MAD). First-frame and resize metrics use
max(10 ms, 5%, 3× MAD); process lifecycle time outside measured frames uses
max(50 ms, 5%, 3× MAD). Peak process RSS may increase by at most 8 MiB, including
font/driver allocations. Capped missed-deadline counts allow max(1 frame,
3× baseline MAD). Throughput loss allows max(5%, 3× baseline repetition MAD).
These are comparison/noise tolerances, not claims that any
increase below them is desirable. Investigate repeated regressions; do not
increase limits in response to candidate results.

The resize workload alternates 1440×900 and 3840×2160 every 30 completed frames,
retaining the GL context or Vulkan device while replacing presentation resources.
Tagged resize frames are excluded from steady-state statistics and reported
separately. Full-process elapsed time minus measured frames captures lifecycle
work outside frame timing. The same compiled probes can load either isolated
baseline libraries or candidate libraries through `--libraries`.

- Define numerical regression limits and noise tolerances from baseline
  measurements before evaluating the new implementation. Do not widen them
  after seeing candidate results to conceal a slowdown.
- Produce a comparison report with baseline and candidate values, absolute and
  percentage differences, run variability, and pass/fail for each workload.
- Require no reproducible adverse effect on steady-state rendering or pacing
  beyond the predefined tolerance. Startup/resize latency and memory must meet
  their separately documented budgets, including the expected atlas storage.
- Investigate and resolve regressions before declaring the feature complete;
  rerun the affected comparisons after fixes. If a regression cannot be resolved,
  record it explicitly and leave the performance gate unmet.
- Preserve commands and raw results with the final report so others can rerun
  the comparison. No manual game testing is required for this gate.

## Scope limitation

A HUD drawn into a low-resolution game output is scaled with that output by
any later compositor or display scaling. A better font cannot guarantee native
display sharpness after this step. Drawing at final display resolution would
require a separate architectural investigation. Where supported, native game
output with reduced internal scene resolution avoids this particular issue.

## Completion criteria

- HUD sizing remains readable and proportional across the validation matrix.
- Both rendering backends use the shared font/layout implementation.
- Automated checks pass, and the same before-and-after benchmark suite passes
  the performance gate with a recorded comparison report and raw results.
- No superseded bitmap rendering path remains.
- Licensing and user documentation are complete.
- Remove this temporary document or move its lasting decisions into maintained
  documentation when planning and implementation are finished.

## Pre-flight results — 2026-09-10

Checked revision: `8b99e859cdacb5cf5372a5965bcbc7f963ac3721`.
Existing local edits to `AGENTS.md` and `README.md` were preserved. This plan
is untracked; no production source changes were made during pre-flight.

| Check | Result |
| --- | --- |
| Repository instructions and rendering interfaces | Inspected; GL already saves texture/sampler state, but atlas upload state and Vulkan descriptors/lifetimes still need implementation review. |
| `make -j4 check-unit check-shell check-docs benchmark-performance` | Passed. Benchmark numbers below are a smoke run, not a controlled performance baseline. |
| `make -j4 all hud-shaders check-abi` | Passed; x86_64 and i386 ABI baselines passed. Existing up-to-date artifacts were reused where appropriate. |
| Toolchain | GCC 15.2.0, glslangValidator, spirv-val, and pkg-config available. Vulkan 1.4.341, EGL 1.5, GL 1.2 pkg-config metadata available. |
| Offline generator prerequisite | `pkg-config freetype2` unavailable. Obtain a pinned repository-local generator/toolchain before asset generation; no system package installation performed. |
| Font input | No JetBrains Mono files found in checked system/user font directories. Import a pinned licensed source into the repository during implementation; do not depend on host fonts. |
| Graphics measurement readiness | DISPLAY is set, but hardware GPU timing and real presentation performance have not been validated. `vulkaninfo`/`glxinfo` not found on PATH; use project probes for further diagnostics. |
| Benchmark coverage | Existing suite covers configuration, metrics cache, and HUD-disabled GLX submission. HUD-enabled Vulkan/OpenGL, resize and memory comparison harness still required before renderer changes. |

Smoke results (nanoseconds): poll 2.207; options 3.454; disabled logging 0.518;
reload 3999.960; metrics cache idle 21.135 / sampling 21.154; GLX present 108.101.
These ran alongside build/check work and must not be used as acceptance limits.
Logs from this check: `/tmp/frame-pacer-preflight.log` and
`/tmp/frame-pacer-preflight-build.log`; temporary logs are not durable baseline
artifacts. The formal benchmark workflow above must preserve its own results.

Readiness: planning and available build checks pass. Before production rendering
changes, complete the benchmark harness and controlled baseline. Before atlas
generation, provision the pinned offline tool and font input within repository
scope. Full GPU integration, sanitizer, and real presentation checks are not
claimed by this pre-flight run and remain implementation validation work.

## Dependency research background — 2026-09-10

Preference: avoid new third-party dependencies for users and contributors.
Selected font: **JetBrains Mono**, confirmed by the user. Verify
Regular and Medium weights in small-size renders before selecting one weight
to ship. Use a pinned, unmodified upstream font as the offline generation input.

JetBrains Mono is licensed under **SIL Open Font License 1.1**, which permits
bundling, embedding, modification and redistribution subject to its conditions.
Include its copyright and full OFL text with the source font and distributed
font assets; keep font-derived assets distinguished from MIT application code.
The application itself can remain MIT-licensed. Review the pinned font's notices
when importing it. No font installation is required for users.
[Upstream license](https://github.com/JetBrains/JetBrainsMono/blob/master/OFL.txt),
[font overview](https://www.jetbrains.com/lp/mono/).

Distinguish runtime libraries, ordinary build dependencies, optional maintainer
asset-generation tools, and third-party font assets. Vendoring a library removes
an installation requirement but does not remove the dependency or upkeep.

### Approaches

| Option | New dependencies | Quality and scaling | Main tradeoff |
| --- | --- | --- | --- |
| Integer-scale existing glyphs | None | Uniform pixel strokes | Size jumps; does not meet proportional scaling goal well. |
| Antialias existing glyph geometry | None | Smooth fractional coverage | Still a 5×7 design; softening alone cannot restore missing shape detail. |
| Project-owned vector glyphs and coverage rasterizer | None, including font assets | Can generate at each required size | We own glyph design, rasterization, small-size tuning, and maintenance. Keep to fixed glyph contours, not a new TrueType parser. |
| Pre-generated coverage atlases at multiple text sizes | No runtime or ordinary build font library; optional generation tool and font asset | Strong small-text potential; select nearest integer text size | More checked-in data; finite size range must be defined. |
| Pre-generated MSDF atlas | No runtime font library; generator/font needed for regeneration | Broad continuous scaling with good corner retention | More complex shader, larger texture channels, and small-text quality needs testing. |
| Runtime TrueType rasterizer | Vendored code or linked library plus font | Flexible sizes and potential font customization | Parser, allocations, rasterization and resource replacement during resizing. |

Dependency-free custom glyphs are feasible because the HUD uses only a small
fixed character set. A simple project-owned polygon coverage generator could
produce atlases without parsing external font formats. This is not guaranteed
to match a professionally designed and hinted font at small sizes.

### Library shortlist and evidence

- **stb_truetype:** single C/C++ header, MIT or public domain. Measured upstream
  header: 199,192 bytes / 5,079 lines (includes comments), not compiled size.
  Version label is 1.26; latest file-history entry returned by GitHub was
  2024-07-15, a merge. Small practical C candidate, but this evidence does not
  establish active rasterizer maintenance. The header explicitly warns against
  untrusted font files. Only a fixed reviewed embedded font would be in scope.
  [Source](https://github.com/nothings/stb/blob/master/stb_truetype.h),
  [history](https://github.com/nothings/stb/commits/master/stb_truetype.h).
- **Dear ImGui's imstb_truetype:** 199,503 bytes / 5,085 lines, a modified stb
  header under its retained license alternatives. No need to import ImGui as a
  whole, but integration macros need review. File history shows integration
  changes in July 2025 and a typo fix in March 2026. This is maintenance evidence,
  not proof of an independently maintained or hardened rasterizer. Similar
  font-parsing limitations to upstream. Best small candidate to evaluate if
  vendored runtime C code becomes necessary.
  [Source](https://github.com/ocornut/imgui/blob/master/imstb_truetype.h),
  [history](https://github.com/ocornut/imgui/commits/master/imstb_truetype.h).
- **FreeType:** strongest maintenance and small-text quality case in this
  shortlist. Official news records 2.14.3 on 2026-03-22. C implementation,
  configurable modules, optional external libraries can be disabled. Supports
  hinting and grayscale coverage. More source/build integration than stb;
  exact stripped binary cost depends on enabled modules and needs measurement.
  Available under the FreeType License or GPLv2; use the FreeType License route
  and retain required notices for this MIT project. Preferred as an optional
  offline atlas-generation tool rather than a shipped runtime dependency.
  [Releases](https://freetype.org/),
  [features and dependencies](https://freetype.org/freetype2/docs/index.html),
  [license](https://github.com/freetype/freetype/blob/master/docs/FTL.TXT).
- **msdfgen:** MIT, C++, suitable as an offline distance-field generator rather
  than a minimal runtime rasterizer. Its core has no external dependencies,
  but its extensions use FreeType, TinyXML2, libpng and optionally Skia.
  More toolchain surface than needed for small fixed HUD text.
  [Project](https://github.com/Chlumsky/msdfgen),
  [release history](https://github.com/Chlumsky/msdfgen/blob/master/CHANGELOG.md).
- **canvas_ity:** compact ISC-licensed C++ 2D renderer with font support, but
  broader than this need. Latest repository commit returned was a CI update
  on 2024-02-29; insufficient evidence to prefer it for active maintenance.
  [Project](https://github.com/a-e-k/canvas_ity).

This is a practical shortlist, not a claim to have proven the smallest library
in existence. Source bytes are not runtime memory, compiled bytes, or build
time. No candidate was installed, compiled, or benchmarked for this research.
Font licensing remains separate from rasterizer licensing. The comparison is
background research; the selected implementation is the offline approach above.

### Selected offline workflow details

Use **pre-generated JetBrains Mono grayscale coverage atlases at integer text sizes**, using
FreeType only in an optional maintainer generation workflow. Check in the raw
atlas data and metrics, licensed font source and notices, and reproducible
generation instructions. Normal builds should not fetch fonts, run a generator,
need FreeType, or require a PNG decoder. Existing packaging remains self-contained.

Select text size from the viewport, round to the nearest supported pixel size,
and render that atlas without stretching its glyphs. One-pixel text-size steps
are substantially finer than integer magnification of the old seven-pixel font.
Spacing should follow the selected metrics. Define the supported size range
explicitly; very small drawables and resolutions beyond the range need a policy.

Illustrative storage budget: 40 glyphs, average cell width about 0.7 times the
height, every height from 10 through 32 pixels: about 306 KiB of 8-bit coverage
before padding/packing. This is an example, not a measured asset size or final
range. Only the selected size needs GPU residency per independently owned atlas;
multiple contexts/devices and transient uploads add allocations. This removes
runtime rasterization, but retains texture upload, backend integration, and
ordinary shader/atlas sampling costs.

Next decisions: select JetBrains Mono weight, supported size range, and grayscale
rasterization settings through deterministic HUD renders. No dependency or
feature code has been added. Implementation must replace the superseded path.
