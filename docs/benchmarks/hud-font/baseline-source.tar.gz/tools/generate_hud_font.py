#!/usr/bin/env python3
"""Reproduce HUD assets with pinned, repository-local FreeType (offline runtime)."""

import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tarfile
import tempfile
from urllib.request import urlopen

ROOT = Path(__file__).resolve().parent.parent
FONT_ROOT = ROOT / "assets/fonts/jetbrains-mono"
VERSION = "2.14.3"
ARCHIVE_SHA256 = "36bc4f1cc413335368ee656c42afca65c5a3987e8768cc28cf11ba775e785a5f"
FONT_HASHES = {
    "Regular": "a0bf60ef0f83c5ed4d7a75d45838548b1f6873372dfac88f71804491898d138f",
    "Medium": "31c92d01a8a08528b718a43addf0ad3df0af2ca4b7b3290a452f70f358e14d3d",
}


def verify(path, expected):
    if hashlib.sha256(path.read_bytes()).hexdigest() != expected:
        raise RuntimeError(f"checksum mismatch: {path}")


def build_generator():
    cache = ROOT / "build/font-tools"
    cache.mkdir(parents=True, exist_ok=True)
    archive = cache / f"freetype-{VERSION}.tar.xz"
    if not archive.exists():
        url = f"https://download.savannah.gnu.org/releases/freetype/freetype-{VERSION}.tar.xz"
        with urlopen(url, timeout=60) as response:
            archive.write_bytes(response.read())
    verify(archive, ARCHIVE_SHA256)
    # Re-extract the verified source so a previous build is not trusted as input.
    source = cache / "pinned-source"
    source.mkdir(exist_ok=True)
    with tarfile.open(archive) as bundle:
        for member in bundle.getmembers():
            path = Path(member.name)
            if path.is_absolute() or ".." in path.parts or not (member.isfile() or member.isdir()):
                raise RuntimeError("unsafe archive member")
        bundle.extractall(source, filter="data")
    source /= f"freetype-{VERSION}"
    subprocess.run([
        "./configure", "--with-zlib=no", "--with-bzip2=no", "--with-png=no",
        "--with-harfbuzz=no", "--with-brotli=no", "--disable-shared", "--enable-static",
    ], cwd=source, check=True, stdout=subprocess.DEVNULL)
    subprocess.run(["make", "-j4"], cwd=source, check=True, stdout=subprocess.DEVNULL)
    executable = cache / "generate-hud-font"
    subprocess.run([
        "cc", "-std=c17", "-O2", "-Wall", "-Wextra", "-Werror", "-Wpedantic",
        f"-I{source / 'include'}", str(ROOT / "tools/generate_hud_font.c"),
        str(source / "objs/.libs/libfreetype.a"), "-o", str(executable),
    ], check=True)
    return executable


def validate(binary, metadata):
    data = binary.read_bytes()
    document = json.loads(metadata.read_text())
    offset = 0
    if [entry["size"] for entry in document["sizes"]] != list(range(8, 65)):
        raise RuntimeError("incomplete size range")
    for entry in document["sizes"]:
        width, height = entry["width"], entry["height"]
        if entry["offset"] != offset:
            raise RuntimeError("invalid atlas offset")
        for character, x, y, w, h, left, top in entry["glyphs"]:
            if not (0 < x and 0 < y and x + w < width and y + h < height):
                raise RuntimeError("glyph exceeds padded atlas bounds")
            if character != 32 and (w == 0 or h == 0):
                raise RuntimeError("empty glyph")
            if left < entry["ink_left"] or left + w > entry["ink_right"]:
                raise RuntimeError("glyph exceeds recorded ink bounds")
            if top > entry["ascent"] or h - top > entry["descent"]:
                raise RuntimeError("glyph exceeds line bounds")
        offset += width * height
    if offset != len(data):
        raise RuntimeError("unexpected atlas length")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--weight", choices=FONT_HASHES, default="Medium")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--check", action="store_true", help="compare without replacing assets")
    args = parser.parse_args()
    font = FONT_ROOT / f"JetBrainsMono-{args.weight}.ttf"
    verify(font, FONT_HASHES[args.weight])
    executable = build_generator()
    environment = os.environ.copy()
    environment.pop("FREETYPE_PROPERTIES", None)
    environment["LC_ALL"] = "C"
    with tempfile.TemporaryDirectory(dir=ROOT / "build/font-tools") as temporary:
        output = Path(temporary)
        binary, metadata = output / "hud-atlas.bin", output / "hud-atlas.json"
        subprocess.run([str(executable), str(font), str(binary), str(metadata)], check=True, env=environment)
        validate(binary, metadata)
        # Independent second generation detects nondeterminism within the toolchain.
        second_binary, second_metadata = output / "second.bin", output / "second.json"
        subprocess.run([str(executable), str(font), str(second_binary), str(second_metadata)], check=True, env=environment)
        if binary.read_bytes() != second_binary.read_bytes() or metadata.read_bytes() != second_metadata.read_bytes():
            raise RuntimeError("nondeterministic font generation")
        manifest = {
            "font": f"JetBrains Mono {args.weight}", "font_version": "2.304",
            "font_sha256": FONT_HASHES[args.weight], "freetype_version": VERSION,
            "freetype_archive_sha256": ARCHIVE_SHA256,
            "load_flags": "FT_LOAD_RENDER | FT_LOAD_TARGET_NORMAL",
            "sizes": [8, 64], "format": "R8_UNORM", "padding": 1,
            "atlas_sha256": hashlib.sha256(binary.read_bytes()).hexdigest(),
            "metadata_sha256": hashlib.sha256(metadata.read_bytes()).hexdigest(),
        }
        (output / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
        if not args.check:
            args.output.mkdir(parents=True, exist_ok=True)
        for name in ("hud-atlas.bin", "hud-atlas.json", "manifest.json"):
            generated = (output / name).read_bytes()
            if args.check:
                if (args.output / name).read_bytes() != generated:
                    raise RuntimeError(f"generated asset differs: {name}")
            else:
                (args.output / name).write_bytes(generated)
        print(f"Verified {args.weight}: {binary.stat().st_size} atlas bytes, 57 sizes")


if __name__ == "__main__":
    main()
